"""Typed request/response models for diffraction simulations."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

import numpy as np


@dataclass
class DetectorGeometry:
    image_size: int
    av: float
    cv: float
    lambda_angstrom: float
    distance_m: float
    gamma_deg: float
    Gamma_deg: float
    chi_deg: float
    psi_deg: float
    psi_z_deg: float
    zs: float
    zb: float
    center: np.ndarray
    theta_initial_deg: float
    cor_angle_deg: float
    unit_x: np.ndarray
    n_detector: np.ndarray
    pixel_size_m: float = 100e-6
    sample_width_m: float = 0.0
    sample_length_m: float = 0.0


@dataclass
class BeamSamples:
    beam_x_array: np.ndarray
    beam_y_array: np.ndarray
    theta_array: np.ndarray
    phi_array: np.ndarray
    wavelength_array: np.ndarray
    sample_weights: np.ndarray | None = None
    n2_sample_array: np.ndarray | None = None


@dataclass
class MosaicParams:
    sigma_mosaic_deg: float
    gamma_mosaic_deg: float
    eta: float
    solve_q_steps: int = 1000
    solve_q_rel_tol: float = 5.0e-4
    solve_q_mode: int = 0


@dataclass
class DebyeWallerParams:
    x: float
    y: float


@dataclass
class SimulationRequest:
    miller: np.ndarray
    intensities: np.ndarray
    geometry: DetectorGeometry
    beam: BeamSamples
    mosaic: MosaicParams
    debye_waller: DebyeWallerParams
    n2: complex
    image_buffer: np.ndarray | None = None
    save_flag: int = 0
    record_status: bool = False
    thickness: float = 0.0
    optics_mode: int | None = None
    collect_hit_tables: bool = True
    accumulate_image: bool = True
    exit_projection_mode: Literal["internal", "refracted"] = "internal"
    best_sample_indices_out: np.ndarray | None = None


@dataclass
class SimulationResult:
    image: np.ndarray
    hit_tables: list[Any]
    q_data: np.ndarray
    q_count: np.ndarray
    all_status: np.ndarray
    miss_tables: list[Any]
    degeneracy: np.ndarray | None = None
    intersection_cache: list[Any] | None = None
    projection_debug: Any | None = None
