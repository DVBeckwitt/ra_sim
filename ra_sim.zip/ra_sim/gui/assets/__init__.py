"""Packaged GUI assets."""
